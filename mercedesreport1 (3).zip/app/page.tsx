import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Car, Calendar, User, MapPin, GraduationCap, Settings, Shield, Thermometer, Wind, Zap } from "lucide-react"
import Image from "next/image"

export default function InternshipReport() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 to-slate-800 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold mb-4">Rapport de Stage</h1>
            <h2 className="text-2xl font-light mb-6">Diagnostics Embarqués en Mécanique Automobile</h2>
            <div className="flex justify-center">
              <Car className="w-16 h-16 text-blue-300" />
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl mx-auto">
            <Card className="bg-white/10 border-white/20">
              <CardContent className="p-4 text-center">
                <User className="w-8 h-8 mx-auto mb-2 text-blue-300" />
                <p className="font-semibold">Stagiaire</p>
                <p className="text-sm">CHRAIT Rabie</p>
              </CardContent>
            </Card>

            <Card className="bg-white/10 border-white/20">
              <CardContent className="p-4 text-center">
                <MapPin className="w-8 h-8 mx-auto mb-2 text-blue-300" />
                <p className="font-semibold">Entreprise</p>
                <p className="text-sm">Mercedes-Benz Oujda</p>
              </CardContent>
            </Card>

            <Card className="bg-white/10 border-white/20">
              <CardContent className="p-4 text-center">
                <Calendar className="w-8 h-8 mx-auto mb-2 text-blue-300" />
                <p className="font-semibold">Période</p>
                <p className="text-sm">21/04/2025 - 17/05/2025</p>
              </CardContent>
            </Card>

            <Card className="bg-white/10 border-white/20">
              <CardContent className="p-4 text-center">
                <GraduationCap className="w-8 h-8 mx-auto mb-2 text-blue-300" />
                <p className="font-semibold">Encadrant</p>
                <p className="text-sm">M. Chebri</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Introduction */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-900">Introduction</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 leading-relaxed">
              Ce stage chez Mercedes-Benz à Oujda, réalisé dans le cadre de ma formation en Diagnostique, m'a permis de
              développer mes compétences en diagnostics embarqués et en mécanique automobile sous l'encadrement de M.
              Chebri. Ce rapport détaille les tâches réalisées par système automobile, les méthodologies employées et
              les compétences acquises durant ce mois.
            </p>
          </CardContent>
        </Card>

        {/* Système Airbag */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-900 flex items-center gap-2">
              <Shield className="w-6 h-6" />
              Système Airbag
            </CardTitle>
            <Badge variant="outline" className="w-fit">
              Temps estimé: 1-2 heures
            </Badge>
          </CardHeader>
          <CardContent className="space-y-8">
            {/* Procédures de démontage airbag */}
            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-800">1. Procédures de Démontage Airbag</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Image
                    src="/images/airbag-procedures.png"
                    alt="Procédures de démontage airbag volant et passager"
                    width={500}
                    height={300}
                    className="rounded-lg border shadow-md"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    <strong>Procédures détaillées:</strong> Étapes de démontage de l'airbag volant, localisation des
                    connecteurs et points de fixation
                  </p>
                </div>
                <div className="space-y-4">
                  <h4 className="font-semibold">Étapes de sécurité:</h4>
                  <ol className="list-decimal list-inside space-y-2 text-sm">
                    <li>Déconnexion de la batterie (attendre 10-15 min)</li>
                    <li>Centrage du volant en position droite</li>
                    <li>Retrait des vis arrière du volant</li>
                    <li>Déclipsage prudent de l'airbag</li>
                    <li>Déconnexion des connecteurs jaune/orange</li>
                  </ol>
                </div>
              </div>
            </div>

            <Separator />

            {/* Localisation des composants */}
            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-800">2. Localisation des Composants</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Image
                    src="/images/airbag-locations.png"
                    alt="Localisation des composants airbag dans l'habitacle"
                    width={500}
                    height={300}
                    className="rounded-lg border shadow-md"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    <strong>Points d'accès:</strong> Localisation des différents composants airbag dans l'habitacle
                    Mercedes
                  </p>
                </div>
                <div>
                  <Image
                    src="/images/airbag-control-unit.png"
                    alt="Calculateur airbag N2/10"
                    width={500}
                    height={300}
                    className="rounded-lg border shadow-md"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    <strong>Calculateur N2/10:</strong> Localisation et points de fixation du calculateur airbag
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded">
              <h4 className="font-semibold text-red-800 mb-2">⚠️ Consignes de Sécurité Airbag</h4>
              <ul className="text-sm text-red-700 space-y-1">
                <li>• Toujours déconnecter la batterie avant intervention</li>
                <li>• Respecter le délai d'attente de 10-15 minutes</li>
                <li>• Manipuler les airbags face vers le bas</li>
                <li>• Ne jamais pointer l'airbag vers une personne</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Système de Refroidissement */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-900 flex items-center gap-2">
              <Thermometer className="w-6 h-6" />
              Système de Refroidissement
            </CardTitle>
            <Badge variant="outline" className="w-fit">
              Temps estimé: 2-4 heures
            </Badge>
          </CardHeader>
          <CardContent className="space-y-8">
            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-800">1. Équipements et Outils Spécialisés</h3>
              <div className="grid md:grid-cols-1 gap-6">
                <div>
                  <Image
                    src="/images/cooling-system.png"
                    alt="Système de refroidissement et outils spécialisés"
                    width={800}
                    height={600}
                    className="rounded-lg border shadow-md"
                  />
                  <div className="mt-4 grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold mb-2">Outils spécialisés Mercedes:</h4>
                      <ul className="text-sm space-y-1">
                        <li>
                          <strong>285 589 01 21 00:</strong> Adaptateur NTKL
                        </li>
                        <li>
                          <strong>210 589 00 91 00:</strong> Bouchon/raccord de contrôle
                        </li>
                        <li>
                          <strong>285 589 02 21 00:</strong> Pompe à vide électrique
                        </li>
                        <li>
                          <strong>285 589 02 21 00:</strong> Appareil de remplissage radiateur
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Procédures:</h4>
                      <ul className="text-sm space-y-1">
                        <li>• Purge du système de refroidissement</li>
                        <li>• Contrôle de pression du circuit</li>
                        <li>• Remplissage sous vide</li>
                        <li>• Test d'étanchéité</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Système EGR et Échappement */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-900 flex items-center gap-2">
              <Wind className="w-6 h-6" />
              Système EGR et Échappement
            </CardTitle>
            <Badge variant="outline" className="w-fit">
              Temps estimé: 2-3 heures
            </Badge>
          </CardHeader>
          <CardContent className="space-y-8">
            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-800">1. Système EGR Haute Pression</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Image
                    src="/images/egr-system.png"
                    alt="Système EGR et composants moteur"
                    width={400}
                    height={300}
                    className="rounded-lg border shadow-md"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    <strong>Diagramme technique:</strong> Localisation de la vanne EGR et circuits associés
                  </p>
                </div>
                <div>
                  <Image
                    src="/images/egr-valve-real.jpeg"
                    alt="Vanne EGR réelle démontée"
                    width={400}
                    height={300}
                    className="rounded-lg border shadow-md"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    <strong>Pièce réelle:</strong> Vanne EGR démontée lors de l'intervention
                  </p>
                </div>
              </div>
            </div>

            <Separator />

            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-800">2. Composants d'Échappement</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Image
                    src="/images/exhaust-components.png"
                    alt="Composants système d'échappement"
                    width={400}
                    height={300}
                    className="rounded-lg border shadow-md"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    <strong>Composants échappement:</strong> Localisation des différents éléments du système
                    d'échappement
                  </p>
                </div>
                <div className="space-y-4">
                  <h4 className="font-semibold">Interventions réalisées:</h4>
                  <ul className="list-disc list-inside space-y-2 text-sm">
                    <li>Changement de la commande EGR haute pression</li>
                    <li>Changement du joint de filtre à particules</li>
                    <li>Nettoyage du circuit AdBlue</li>
                    <li>Contrôle des capteurs NOx</li>
                    <li>Diagnostic des codes défauts</li>
                  </ul>
                </div>
              </div>
            </div>

            <Separator />

            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-800">3. Système Turbocompresseur</h3>
              <div className="grid md:grid-cols-1 gap-6">
                <div>
                  <Image
                    src="/images/turbocharger-system.png"
                    alt="Système turbocompresseur monostage"
                    width={600}
                    height={400}
                    className="rounded-lg border shadow-md mx-auto"
                  />
                  <p className="text-sm text-gray-600 mt-2 text-center">
                    <strong>Turbocompresseur monostage:</strong> Composants et connexions du système de suralimentation
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Système Moteur */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-900 flex items-center gap-2">
              <Zap className="w-6 h-6" />
              Système Moteur
            </CardTitle>
            <Badge variant="outline" className="w-fit">
              Temps estimé: Variable selon intervention
            </Badge>
          </CardHeader>
          <CardContent className="space-y-8">
            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-800">1. Compartiment Moteur</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Image
                    src="/images/engine-compartment.png"
                    alt="Vue compartiment moteur Mercedes"
                    width={500}
                    height={300}
                    className="rounded-lg border shadow-md"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    <strong>Compartiment moteur:</strong> Localisation des principaux composants moteur Mercedes-Benz
                  </p>
                </div>
                <div className="space-y-4">
                  <h4 className="font-semibold">Interventions moteur:</h4>
                  <ul className="list-disc list-inside space-y-2 text-sm">
                    <li>Changement de courroie de distribution</li>
                    <li>Remplacement des optiques avec adaptation</li>
                    <li>Mise à jour des calculateurs moteur</li>
                    <li>Contrôle des systèmes d'injection</li>
                    <li>Diagnostic des capteurs moteur</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Présentation - Systèmes de Dépollution et Turbocompresseurs */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-900 flex items-center gap-2">
              <Wind className="w-6 h-6" />
              Présentation - Technologies Mercedes-Benz
            </CardTitle>
            <Badge variant="outline" className="w-fit">
              Formation technique approfondie
            </Badge>
          </CardHeader>
          <CardContent className="space-y-8">
            {/* Systèmes de Dépollution */}
            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-800">
                1. Systèmes de Dépollution des Moteurs Essence
              </h3>
              <p className="text-gray-700 mb-6 italic">
                "Une plume pour la planète" - Mercedes-Benz sculpte des moteurs essence où la puissance s'enlace à la
                pureté, avec des systèmes de dépollution d'une grâce infinie pour un horizon neutre en carbone d'ici
                2039.
              </p>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded">
                  <h4 className="font-semibold text-red-800 mb-3">🔥 Naissance des Gaz Polluants</h4>
                  <div className="space-y-3 text-sm">
                    <div>
                      <strong>Monoxyde de carbone (CO):</strong>
                      <p>Né d'une combustion incomplète (mélange riche {"<"} 14,7:1)</p>
                      <p className="text-xs text-gray-600">Réaction: 2C + O₂ → 2CO</p>
                    </div>
                    <div>
                      <strong>Hydrocarbures non brûlés (HC):</strong>
                      <p>Vestiges d'essence échappant à la combustion</p>
                    </div>
                    <div>
                      <strong>Oxydes d'azote (NOx):</strong>
                      <p>Forgés dans la fournaise ({">"} 1500°C)</p>
                      <p className="text-xs text-gray-600">Réaction: N₂ + O₂ → 2NO</p>
                    </div>
                    <div>
                      <strong>Particules fines:</strong>
                      <p>Issues des moteurs GDI lors de combustions riches</p>
                    </div>
                  </div>
                </div>

                <div className="bg-green-50 border-l-4 border-green-400 p-4 rounded">
                  <h4 className="font-semibold text-green-800 mb-3">🛡️ Systèmes de Dépollution</h4>
                  <div className="space-y-3 text-sm">
                    <div>
                      <strong>TWC (Three-Way Catalyst):</strong>
                      <p>Convertisseur catalytique à trois voies - CO, HC, NOx</p>
                    </div>
                    <div>
                      <strong>EGR (Exhaust Gas Recirculation):</strong>
                      <p>Recirculation des gaz d'échappement - NOx</p>
                    </div>
                    <div>
                      <strong>GPF (Gasoline Particulate Filter):</strong>
                      <p>Filtre à particules essence - Particules fines</p>
                    </div>
                    <div>
                      <strong>SCR (Selective Catalytic Reduction):</strong>
                      <p>Réduction catalytique avec AdBlue - 95% des NOx</p>
                    </div>
                    <div>
                      <strong>PCV (Positive Crankcase Ventilation):</strong>
                      <p>Ventilation du carter - HC vapeurs</p>
                    </div>
                    <div>
                      <strong>PI (Post-Injection):</strong>
                      <p>Post-injection pour régénération GPF</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-gray-300 text-sm">
                  <thead>
                    <tr className="bg-blue-100">
                      <th className="border border-gray-300 p-2">Système</th>
                      <th className="border border-gray-300 p-2">Abréviation</th>
                      <th className="border border-gray-300 p-2">Gaz Domptés</th>
                      <th className="border border-gray-300 p-2">Capteurs Principaux</th>
                      <th className="border border-gray-300 p-2">Alchimie</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-gray-300 p-2">Convertisseur catalytique</td>
                      <td className="border border-gray-300 p-2 font-mono">TWC</td>
                      <td className="border border-gray-300 p-2">CO, HC, NOx</td>
                      <td className="border border-gray-300 p-2">Sondes lambda, température</td>
                      <td className="border border-gray-300 p-2">Oxydation + Réduction</td>
                    </tr>
                    <tr className="bg-gray-50">
                      <td className="border border-gray-300 p-2">Recirculation gaz</td>
                      <td className="border border-gray-300 p-2 font-mono">EGR</td>
                      <td className="border border-gray-300 p-2">NOx</td>
                      <td className="border border-gray-300 p-2">Pression différentielle</td>
                      <td className="border border-gray-300 p-2">Dilution refroidissement</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 p-2">Filtre à particules</td>
                      <td className="border border-gray-300 p-2 font-mono">GPF</td>
                      <td className="border border-gray-300 p-2">Particules</td>
                      <td className="border border-gray-300 p-2">Pression, température</td>
                      <td className="border border-gray-300 p-2">Capture + Oxydation</td>
                    </tr>
                    <tr className="bg-gray-50">
                      <td className="border border-gray-300 p-2">Réduction catalytique</td>
                      <td className="border border-gray-300 p-2 font-mono">SCR</td>
                      <td className="border border-gray-300 p-2">NOx</td>
                      <td className="border border-gray-300 p-2">NOx, température, AdBlue</td>
                      <td className="border border-gray-300 p-2">NH₃ + NOx → N₂ + H₂O</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <Separator />

            {/* Turbocompresseurs */}
            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-800">2. Turbocompresseurs et Capteurs Mercedes</h3>
              <p className="text-gray-700 mb-6">
                Les technologies de turbocompression Mercedes offrent puissance, réactivité et efficacité, des systèmes
                classiques aux innovations MGU-H inspirées de la Formule 1.
              </p>

              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded mb-6">
                <h4 className="font-semibold text-yellow-800 mb-2">⚡ Le Turbo Lag</h4>
                <p className="text-sm text-yellow-700">
                  Délai entre l'accélérateur et la montée en puissance, dû à l'inertie de la turbine. À bas régime, les
                  gaz d'échappement manquent de pression. Les technologies Mercedes (e-turbo, MGU-H) réduisent ce
                  problème dans les Classe C et AMG GT.
                </p>
              </div>

              <div className="grid md:grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold text-blue-700 mb-2">🔧 Turbocompresseur Classique</h4>
                    <p className="text-sm mb-2">
                      <strong>Modèles:</strong> Mercedes Classe C (C 250)
                    </p>
                    <p className="text-sm mb-2">
                      <strong>Vitesse:</strong> Jusqu'à 200 000 tr/min
                    </p>
                    <p className="text-sm mb-2">
                      <strong>Température:</strong> Gaz jusqu'à 1000°C
                    </p>
                    <div className="text-xs text-gray-600">
                      <strong>Capteurs:</strong> MAP, IAT, Vitesse, Wastegate, Huile, EGT
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold text-blue-700 mb-2">🔄 Split-Turbo</h4>
                    <p className="text-sm mb-2">
                      <strong>Modèles:</strong> Mercedes Classe S (S 560)
                    </p>
                    <p className="text-sm mb-2">
                      <strong>Innovation:</strong> Turbine et compresseur séparés
                    </p>
                    <p className="text-sm mb-2">
                      <strong>Avantage:</strong> Meilleur refroidissement
                    </p>
                    <div className="text-xs text-gray-600">
                      <strong>Capteurs:</strong> MAP, IAT, MGU-H Vitesse, Courant, EGT
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold text-blue-700 mb-2">🌪️ Twin-Scroll Turbo</h4>
                    <p className="text-sm mb-2">
                      <strong>Modèles:</strong> AMG GT (GT 63)
                    </p>
                    <p className="text-sm mb-2">
                      <strong>Innovation:</strong> Deux volutes séparées
                    </p>
                    <p className="text-sm mb-2">
                      <strong>Avantage:</strong> Réactivité à bas régime
                    </p>
                    <div className="text-xs text-gray-600">
                      <strong>Capteurs:</strong> MAP, IAT, Vitesse, Wastegate, Débit
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold text-blue-700 mb-2">⚡ Turbocompresseur Électrique</h4>
                    <p className="text-sm mb-2">
                      <strong>Modèles:</strong> AMG C 43
                    </p>
                    <p className="text-sm mb-2">
                      <strong>Tension:</strong> Système 48V
                    </p>
                    <p className="text-sm mb-2">
                      <strong>Avantage:</strong> Élimination turbo lag
                    </p>
                    <div className="text-xs text-gray-600">
                      <strong>Capteurs:</strong> MAP, IAT, Vitesse électrique, Courant, Température
                    </div>
                  </div>

                  <div className="border rounded-lg p-4 bg-green-50">
                    <h4 className="font-semibold text-green-700 mb-2">🏎️ MGU-H (Motor Generator Unit)</h4>
                    <p className="text-sm mb-2">
                      <strong>Modèles:</strong> AMG GT 53
                    </p>
                    <p className="text-sm mb-2">
                      <strong>Origine:</strong> Technologie Formule 1
                    </p>
                    <p className="text-sm mb-2">
                      <strong>Puissance:</strong> Jusqu'à 10 kW
                    </p>
                    <p className="text-sm mb-2">
                      <strong>Double fonction:</strong> Moteur + Générateur
                    </p>
                    <div className="text-xs text-gray-600">
                      <strong>Capteurs:</strong> Vitesse MGU-H, Courant, EGT, MAP, Température
                    </div>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="font-semibold text-blue-800 mb-2">📊 Capteurs Communs</h4>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <strong>MAP:</strong> Pression admission
                      </div>
                      <div>
                        <strong>IAT:</strong> Température air
                      </div>
                      <div>
                        <strong>EGT:</strong> Température gaz échappement
                      </div>
                      <div>
                        <strong>Wastegate:</strong> Régulation pression
                      </div>
                      <div>
                        <strong>Huile:</strong> Lubrification
                      </div>
                      <div>
                        <strong>Vitesse:</strong> Rotation turbine
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Innovation et Évolution */}
            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-800">3. L'Horizon des Innovations Mercedes</h3>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-gradient-to-b from-blue-50 to-blue-100 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">1970-1980</div>
                  <div className="text-sm text-blue-700">TWC et sondes lambda émergent</div>
                </div>
                <div className="text-center p-4 bg-gradient-to-b from-green-50 to-green-100 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">1990-2000</div>
                  <div className="text-sm text-green-700">EGR dompte les NOx</div>
                </div>
                <div className="text-center p-4 bg-gradient-to-b from-purple-50 to-purple-100 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">2020+</div>
                  <div className="text-sm text-purple-700">MGU-H et SCR, NOx {"<"} 20 mg/km</div>
                </div>
              </div>

              <div className="mt-6 bg-gradient-to-r from-blue-50 to-green-50 border border-blue-200 rounded-lg p-6">
                <h4 className="font-semibold text-blue-800 mb-3">🚀 Technologies d'Avenir Mercedes-Benz</h4>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <ul className="space-y-2">
                    <li>
                      • <strong>TWC à démarrage rapide:</strong> Capture CO et HC dès le premier souffle
                    </li>
                    <li>
                      • <strong>GPF catalytiques:</strong> Purifient particules, CO, HC en un geste
                    </li>
                    <li>
                      • <strong>SCR sur essence:</strong> Élimine 95% des NOx, prêt pour Euro 7
                    </li>
                  </ul>
                  <ul className="space-y-2">
                    <li>
                      • <strong>Hybrides élégants:</strong> Classe C alliant dépollution et électrification
                    </li>
                    <li>
                      • <strong>Capteurs d'avenir:</strong> NOx et particules surveillés en temps réel
                    </li>
                    <li>
                      • <strong>Objectif 2039:</strong> Neutralité carbone Mercedes-Benz
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Vidange Boîte 9G-Tronic - Version complète */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-900 flex items-center gap-2">
              <Settings className="w-6 h-6" />
              Vidange Boîte de Vitesse 9G-Tronic
            </CardTitle>
            <Badge variant="outline" className="w-fit">
              Temps estimé: 1,5 à 4 heures
            </Badge>
          </CardHeader>
          <CardContent className="space-y-8">
            {/* Introduction */}
            <div>
              <p className="text-gray-700 mb-6">
                La transmission automatique 9G-Tronic Mercedes-Benz représente l'une des boîtes de vitesse les plus
                avancées au monde. Cette intervention complexe nécessite des outils spécialisés Mercedes-Benz, un
                diagnostic précis des niveaux d'huile et le respect strict des procédures constructeur.
              </p>

              <div className="grid md:grid-cols-3 gap-4 mb-6">
                <div className="text-center p-4 bg-red-50 border border-red-200 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">49.2mm</div>
                  <div className="text-sm text-gray-600">Niveau Minimal</div>
                  <div className="text-xs text-red-500">Risque de dommages</div>
                </div>
                <div className="text-center p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">53.2mm</div>
                  <div className="text-sm text-gray-600">Niveau Nominal</div>
                  <div className="text-xs text-green-500">Fonctionnement optimal</div>
                </div>
                <div className="text-center p-4 bg-orange-50 border border-orange-200 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">57.2mm</div>
                  <div className="text-sm text-gray-600">Niveau Maximal</div>
                  <div className="text-xs text-orange-500">Ne pas dépasser</div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Outils et équipements spécialisés */}
            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-800">1. Outils et Équipements Spécialisés</h3>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Image
                    src="/images/9g-tronic-technical.png"
                    alt="Outils spécialisés 9G-Tronic et schémas techniques"
                    width={600}
                    height={400}
                    className="rounded-lg border shadow-md"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    <strong>Outils Mercedes spécialisés:</strong> Clés à douille et adaptateurs spécifiques pour
                    l'intervention sur carter d'huile 9G-Tronic
                  </p>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-blue-700">Outillage spécialisé Mercedes:</h4>
                  <div className="grid gap-3">
                    <div className="border rounded-lg p-3 bg-gray-50">
                      <div className="font-mono text-sm font-bold text-blue-600">724 589 01 09 00</div>
                      <div className="text-sm">Clé à douille spéciale carter d'huile</div>
                    </div>
                    <div className="border rounded-lg p-3 bg-gray-50">
                      <div className="font-mono text-sm font-bold text-blue-600">725 589 00 90 00</div>
                      <div className="text-sm">Adaptateur de vidange</div>
                    </div>
                    <div className="border rounded-lg p-3 bg-gray-50">
                      <div className="font-mono text-sm font-bold text-blue-600">725 589 00 09 00</div>
                      <div className="text-sm">Clé à douille de remplissage</div>
                    </div>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h5 className="font-semibold text-blue-800 mb-2">Équipements de diagnostic:</h5>
                    <ul className="text-sm space-y-1">
                      <li>• Interface XENTRY/SDconnect</li>
                      <li>• Thermomètre de précision ATF</li>
                      <li>• Jauge de niveau électronique</li>
                      <li>• Pont élévateur ou fosses</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Procédure détaillée en 5 étapes */}
            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-800">2. Procédure Complète de Vidange</h3>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <Image
                    src="/images/9g-tronic-intervention.png"
                    alt="Intervention pratique sur boîte 9G-Tronic"
                    width={600}
                    height={400}
                    className="rounded-lg border shadow-md"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    <strong>Intervention en cours:</strong> Vue technique de la boîte, diagnostic XENTRY, accès sous
                    véhicule et équipements de mesure
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded">
                    <h4 className="font-semibold text-yellow-800 mb-2">⚠️ Conditions préalables</h4>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Température huile ATF: 45-80°C (optimal 60°C)</li>
                      <li>• Véhicule sur surface plane</li>
                      <li>• Moteur au ralenti, sélecteur en position P</li>
                      <li>• Frein de stationnement serré</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Étapes détaillées */}
              <div className="space-y-6">
                {/* Étape 1 */}
                <div className="border-l-4 border-blue-500 pl-6 py-4 bg-blue-50 rounded-r-lg">
                  <h4 className="text-lg font-semibold text-blue-800 mb-3">
                    Étape 1: Levage du véhicule et accès à la boîte de vitesse
                  </h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h5 className="font-semibold mb-2">Procédure de levage:</h5>
                      <ol className="list-decimal list-inside space-y-2 text-sm">
                        <li>Positionnement du véhicule sur le pont élévateur</li>
                        <li>Vérification des points de levage Mercedes</li>
                        <li>Levage progressif jusqu'à hauteur de travail</li>
                        <li>Sécurisation avec chandelles si nécessaire</li>
                        <li>Retrait du cache de protection sous-moteur</li>
                      </ol>
                    </div>
                    <div>
                      <h5 className="font-semibold mb-2">Points d'accès identifiés:</h5>
                      <ul className="list-disc list-inside space-y-1 text-sm">
                        <li>Carter d'huile 9G-Tronic (position 32-33)</li>
                        <li>Bouchon de vidange magnétique</li>
                        <li>Bouchon de remplissage/contrôle</li>
                        <li>Connecteur diagnostic boîte</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Étape 2 */}
                <div className="border-l-4 border-orange-500 pl-6 py-4 bg-orange-50 rounded-r-lg">
                  <h4 className="text-lg font-semibold text-orange-800 mb-3">
                    Étape 2: Vidange de l'huile usagée via le bouchon de vidange
                  </h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h5 className="font-semibold mb-2">Procédure de vidange:</h5>
                      <ol className="list-decimal list-inside space-y-2 text-sm">
                        <li>Montée en température de l'huile ATF (60°C)</li>
                        <li>Positionnement du bac de récupération (12L min)</li>
                        <li>Dévissage du bouchon de vidange avec clé spéciale</li>
                        <li>Évacuation complète de l'huile usagée</li>
                        <li>Nettoyage du bouchon magnétique</li>
                        <li>Contrôle de l'état de l'huile évacuée</li>
                      </ol>
                    </div>
                    <div>
                      <div className="bg-red-50 border border-red-200 rounded p-3">
                        <h5 className="font-semibold text-red-800 mb-2">Analyse de l'huile usagée:</h5>
                        <ul className="text-sm text-red-700 space-y-1">
                          <li>• Couleur: Rouge foncé = normal</li>
                          <li>• Odeur: Brûlée = surchauffe</li>
                          <li>• Particules: Métalliques = usure</li>
                          <li>• Consistance: Épaisse = dégradation</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Étape 3 */}
                <div className="border-l-4 border-green-500 pl-6 py-4 bg-green-50 rounded-r-lg">
                  <h4 className="text-lg font-semibold text-green-800 mb-3">Étape 3: Remplacement du carter d'huile</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h5 className="font-semibold mb-2">Démontage carter:</h5>
                      <ol className="list-decimal list-inside space-y-2 text-sm">
                        <li>Dévissage des vis de fixation carter (couple spécifique)</li>
                        <li>Dépose délicate du carter d'huile</li>
                        <li>Retrait du filtre à huile interne</li>
                        <li>Nettoyage complet des surfaces d'étanchéité</li>
                        <li>Contrôle des aimants de récupération</li>
                      </ol>
                    </div>
                    <div>
                      <h5 className="font-semibold mb-2">Remontage avec pièces neuves:</h5>
                      <ol className="list-decimal list-inside space-y-2 text-sm">
                        <li>Installation du filtre à huile neuf</li>
                        <li>Pose du joint d'étanchéité neuf</li>
                        <li>Remontage du carter avec couple de serrage</li>
                        <li>Vérification de l'alignement</li>
                        <li>Contrôle visuel de l'étanchéité</li>
                      </ol>
                    </div>
                  </div>

                  <div className="mt-4 bg-green-100 border border-green-300 rounded p-3">
                    <h5 className="font-semibold text-green-800 mb-2">Couples de serrage Mercedes:</h5>
                    <div className="grid md:grid-cols-3 gap-2 text-sm">
                      <div>
                        Vis carter: <strong>8 Nm</strong>
                      </div>
                      <div>
                        Bouchon vidange: <strong>35 Nm</strong>
                      </div>
                      <div>
                        Bouchon remplissage: <strong>25 Nm</strong>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Étape 4 */}
                <div className="border-l-4 border-purple-500 pl-6 py-4 bg-purple-50 rounded-r-lg">
                  <h4 className="text-lg font-semibold text-purple-800 mb-3">
                    Étape 4: Remplissage avec l'huile spécifique pour boîte 9G-Tronic
                  </h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h5 className="font-semibold mb-2">Spécifications huile ATF:</h5>
                      <div className="bg-purple-100 border border-purple-300 rounded p-3 text-sm">
                        <div>
                          <strong>Type:</strong> MB 236.17 (ATF 9G-Tronic)
                        </div>
                        <div>
                          <strong>Quantité:</strong> 8,5 - 9,5 litres
                        </div>
                        <div>
                          <strong>Température service:</strong> -40°C à +150°C
                        </div>
                        <div>
                          <strong>Viscosité:</strong> Spécifique 9G-Tronic
                        </div>
                      </div>
                    </div>
                    <div>
                      <h5 className="font-semibold mb-2">Procédure de remplissage:</h5>
                      <ol className="list-decimal list-inside space-y-2 text-sm">
                        <li>Connexion XENTRY pour contrôle température</li>
                        <li>Remplissage initial par bouchon de remplissage</li>
                        <li>Démarrage moteur et montée en température</li>
                        <li>Passages dans toutes les positions (P-R-N-D-S)</li>
                        <li>Ajustement niveau selon mesure XENTRY</li>
                        <li>Contrôle final à température de service</li>
                      </ol>
                    </div>
                  </div>
                </div>

                {/* Étape 5 */}
                <div className="border-l-4 border-indigo-500 pl-6 py-4 bg-indigo-50 rounded-r-lg">
                  <h4 className="text-lg font-semibold text-indigo-800 mb-3">
                    Étape 5: Test de conduite pour vérifier les passages de vitesse
                  </h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h5 className="font-semibold mb-2">Protocole de test:</h5>
                      <ol className="list-decimal list-inside space-y-2 text-sm">
                        <li>Adaptation électronique via XENTRY</li>
                        <li>Effacement des codes défauts mémorisés</li>
                        <li>Test statique: P-R-N-D-S (moteur au ralenti)</li>
                        <li>Test dynamique: accélérations progressives</li>
                        <li>Contrôle des 9 rapports en montée/descente</li>
                        <li>Vérification mode manuel et sport</li>
                      </ol>
                    </div>
                    <div>
                      <h5 className="font-semibold mb-2">Points de contrôle:</h5>
                      <ul className="list-disc list-inside space-y-1 text-sm">
                        <li>Douceur des passages de vitesse</li>
                        <li>Absence de à-coups ou glissements</li>
                        <li>Réactivité du kick-down</li>
                        <li>Fonctionnement du mode éco/sport</li>
                        <li>Température de fonctionnement stable</li>
                        <li>Absence de codes défauts</li>
                      </ul>

                      <div className="mt-3 bg-indigo-100 border border-indigo-300 rounded p-3">
                        <h6 className="font-semibold text-indigo-800 mb-1">Diagnostic final XENTRY:</h6>
                        <div className="text-xs text-indigo-700">
                          Lecture des adaptations, contrôle des pressions hydrauliques et validation du bon
                          fonctionnement de tous les systèmes.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Consignes de sécurité et recommandations */}
            <div>
              <h3 className="text-xl font-semibold mb-4 text-blue-800">3. Consignes de Sécurité et Recommandations</h3>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded">
                  <h4 className="font-semibold text-red-800 mb-3">⚠️ Sécurité Obligatoire</h4>
                  <ul className="text-sm text-red-700 space-y-2">
                    <li>• Port des EPI: gants, lunettes, chaussures de sécurité</li>
                    <li>• Attention à la température de l'huile ATF (risque de brûlure)</li>
                    <li>• Respect des couples de serrage Mercedes</li>
                    <li>• Utilisation exclusive d'huile MB 236.17</li>
                    <li>• Contrôle obligatoire avec XENTRY</li>
                    <li>• Test de conduite supervisé après intervention</li>
                  </ul>
                </div>

                <div className="bg-green-50 border-l-4 border-green-400 p-4 rounded">
                  <h4 className="font-semibold text-green-800 mb-3">✅ Bonnes Pratiques</h4>
                  <ul className="text-sm text-green-700 space-y-2">
                    <li>• Vidange préventive tous les 80 000 km</li>
                    <li>• Remplacement systématique du filtre</li>
                    <li>• Nettoyage minutieux des surfaces</li>
                    <li>• Documentation de l'intervention</li>
                    <li>• Formation continue sur évolutions 9G-Tronic</li>
                    <li>• Archivage des paramètres XENTRY</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Conclusion */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-blue-900">Conclusion</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 leading-relaxed mb-4">
              Ce stage chez Mercedes-Benz à Oujda a été une expérience enrichissante, tant sur le plan technique que
              professionnel. J'ai acquis des compétences pratiques sur tous les systèmes automobiles modernes : airbag,
              refroidissement, EGR/échappement, moteur et transmission.
            </p>
            <p className="text-gray-700 leading-relaxed">
              Sous l'encadrement de M. Chebri, j'ai appris l'importance de la précision, du respect des procédures
              constructeur et de l'utilisation des équipements spécialisés pour chaque système. Cette approche
              systémique m'a préparé aux défis technologiques de l'automobile moderne.
            </p>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-12 text-gray-500">
          <Separator className="mb-4" />
          <p>Année académique 2024-2025 • Mercedes-Benz Oujda</p>
        </div>
      </div>
    </div>
  )
}
